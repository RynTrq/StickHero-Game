module com.example.ap_game {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.ap_game to javafx.fxml;
    exports com.example.ap_game;
}
package com.example.ap_game;

import javafx.animation.*;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.application.Application;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class Scene3Controller {
    public void Control() {

    }
    @FXML
    private Button homeScreenButton;

    public void initialize() {
        // Set the color of the button
        homeScreenButton.setStyle("-fx-background-color: #0069ff;");

        Image image = new Image("C:\\Users\\Raiyaan\\Downloads\\Home.png");
        ImageView imageView = new ImageView(image);

        // Set the dimensions of the image to fit into the button
        imageView.setFitWidth(homeScreenButton.getPrefWidth());
        imageView.setFitHeight(homeScreenButton.getPrefHeight());
        homeScreenButton.setGraphic(imageView);
    }
    public void HomeScreen() throws IOException {
        // Load Scene1.fxml
        Parent root = FXMLLoader.load(getClass().getResource("/com/example/ap_game/Scene1.fxml"));

        // Create a new scene with the loaded root
        Scene scene = new Scene(root);

        // Get the current stage
        Stage stage = (Stage) homeScreenButton.getScene().getWindow();

        // Set the new scene to the stage
        stage.setScene(scene);
    }
}

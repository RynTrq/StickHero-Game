package com.example.ap_game;

import javafx.fxml.FXML;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Line;

public class Scene2Controller {

    @FXML
    private Pane rootPane;

    private Line verticalLine;
    private boolean isKPressed = false;

    @FXML
    public void initialize() {
        // Initialize the line at the start (you can set initial properties)
        verticalLine = new Line(458, 50, 50, 100);
        rootPane.getChildren().add(verticalLine);

        // Set up the event handlers for key presses and releases
        rootPane.setOnKeyPressed(this::handleKeyPress);
        rootPane.setOnKeyReleased(this::handleKeyRelease);
        rootPane.requestFocus(); // Make sure the pane can receive key events
    }

    private void handleKeyPress(KeyEvent event) {
        if (event.getCode() == KeyCode.K && !isKPressed) {
            isKPressed = true;
            // Start a task to continuously increase the length of the line
            startIncreasingLineTask();
        }
    }

    private void handleKeyRelease(KeyEvent event) {
        if (event.getCode() == KeyCode.K) {
            isKPressed = false;
        }
    }

    private void startIncreasingLineTask() {
        // Create a task that increases the length of the line until 'K' is released
        Thread task = new Thread(() -> {
            while (isKPressed) {
                // Increase the height of the line in the vertical direction
                verticalLine.setEndY(verticalLine.getEndY() + 1);
                try {
                    Thread.sleep(10); // Adjust the sleep duration as needed
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });

        // Start the task in a new thread
        task.start();
    }
}

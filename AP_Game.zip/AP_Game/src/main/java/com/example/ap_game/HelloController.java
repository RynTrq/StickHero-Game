package com.example.ap_game;

import javafx.animation.*;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.application.Application;
import javafx.scene.control.Label;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

public class HelloController {
    private Stage stage;
    private Scene scene;
    private Parent root;
    private Line line;
    private double lineLength = 1.0;
    private double startx = 93;
    private double starty = 500;
    private double endx = 93;
    private double endy = 500;
    private double ladderEndCoordinate = startx;
    private double prevLadderEndCoordinate = 93.0;
    private boolean newLadder = true;
    private final double paneWidth = 600.0;
    private double prevBase = 93;
    private List<List<Double>> hillList = new ArrayList<>();
    private Rectangle startRectangle;
    private Rectangle rectangle;
    private Rectangle midRectangle;
    private Rectangle baseMidRectangle;
    double breadth;
    double xCoordinate;
    private Line prevLine = new Line(0, 0, 0, 0);
    private ImageView imageView;
    private int Score = 0;


    public void startGame(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Scene2.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();

        startRectangle = new Rectangle(93, 200);
        startRectangle.setLayoutY(500);
        startRectangle.setFill(Color.BLACK);

        baseMidRectangle = new Rectangle(5, 5);
        baseMidRectangle.setLayoutY(500);
        baseMidRectangle.setLayoutX(46.5);
        baseMidRectangle.setFill(Color.RED);

        Image image = new Image("D:\\PadhaiLikhai\\MyCodes\\Java\\AP_Game\\src\\main\\java\\com\\example\\ap_game\\Stickhero.png");

        imageView = new ImageView(image);
        imageView.setFitWidth(40);
        imageView.setFitHeight(40);
        imageView.setX(50);
        imageView.setY(460);

        Group rootGroup = new Group(root, startRectangle, baseMidRectangle,imageView);

        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(rootGroup);

        // Set event handlers for key press and release
        scene.setOnKeyPressed(e -> handleKeyPress(e.getCode()));
        scene.setOnKeyReleased(e -> handleKeyRelease());

        generateHills();
        addLine();

        for (List<Double> innerList : hillList) {

            for (Double value : innerList) {
                System.out.print(value + " ");
            }

            System.out.println(); // Move to the next line for each inner list
        }

        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }

    private void checkLadder() {
        boolean isLadder = false;
        Iterator<List<Double>> iterator = hillList.iterator();
        while (iterator.hasNext()) {
            List<Double> ite = iterator.next();
            System.out.println(ladderEndCoordinate + " " + ite.get(0) + " " + (ite.get(0) + ite.get(1)));
            if (ladderEndCoordinate >= ite.get(0) && ladderEndCoordinate <= (ite.get(0) + ite.get(1))) {
                double ordinate = ite.get(0);
                double wid = ite.get(1);
                iterator.remove();
                isLadder = true;

                if(ladderEndCoordinate >= ite.get(0) + (breadth / 2) - midRectangle.getWidth() && ladderEndCoordinate <= ite.get(0) + (breadth / 2) + midRectangle.getWidth()) {
                    displayBonus("BONUS!");
                    Score += 2;
                }
                else Score++;

                moveSubject(ordinate + wid);
                break;
            }
        }

        if(!isLadder){
            moveTillDeath(ladderEndCoordinate);
        }
    }

    private void moveTillDeath(double ladderEndCoordinate) {
        // Create a TranslateTransition
        TranslateTransition translateTransition = new TranslateTransition();
        translateTransition.setNode(imageView);
        translateTransition.setByX(ladderEndCoordinate - startRectangle.getWidth() + imageView.getFitWidth());
        translateTransition.setDuration(Duration.seconds(1));

        translateTransition.play();

        // Set an event handler to be triggered when the animation finishes
        translateTransition.setOnFinished(event -> {
            TranslateTransition fallTransition = new TranslateTransition();
            fallTransition.setNode(imageView);
            fallTransition.setByY(500);
            fallTransition.setDuration(Duration.seconds(1));

            fallTransition.setOnFinished(event1 -> {
                // Instead of printing to the terminal, display the bonus on the scene
                try {
                    // Load the new FXML file (scene3.fxml)
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("scene3.fxml"));
                    Parent root = loader.load();

                    // Set the new scene in the stage
                    Scene newScene = new Scene(root);
                    stage.setScene(newScene);

                    // Show the stage with the new scene
                    stage.show();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });

            // Start the animation
            fallTransition.play();
        });
        System.out.println("Score : " + Score);
    }

    // Method to display bonus on the scene
    private void displayBonus(String bonusMessage) {
        Label bonusLabel = new Label(bonusMessage);
        bonusLabel.setLayoutX(200);
        bonusLabel.setLayoutY(300);
        bonusLabel.setStyle("-fx-font-size: 50; -fx-font-weight: bold; -fx-text-fill: red;");

        Group rootGroup = (Group) scene.getRoot();
        rootGroup.getChildren().add(bonusLabel);

        // Create a FadeTransition to make the bonus label disappear after a while
        FadeTransition fadeOut = new FadeTransition(Duration.seconds(2), bonusLabel);
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);

        // Set an event handler to remove the bonus label after it fades out
        fadeOut.setOnFinished(event -> rootGroup.getChildren().remove(bonusLabel));

        // Start the fade-out animation
        fadeOut.play();
    }

    private void moveSubject(double baseEndOrdinate) {
        // Create a TranslateTransition
        TranslateTransition translateTransition = new TranslateTransition();
        translateTransition.setNode(imageView);
        translateTransition.setByX(baseEndOrdinate - prevLadderEndCoordinate);
        translateTransition.setDuration(Duration.seconds(1));

        prevLadderEndCoordinate = breadth;

        // Set an event handler to be triggered when the animation finishes
        translateTransition.setOnFinished(event -> runParallel());

        // Start the animation
        translateTransition.play();
    }

    private void addLine() {
        System.out.println("line dimention: " + startx + " " + endx);
        lineLength = 1.0;
        line = new Line(startx, starty, endx, endy);
        line.setStroke(Color.BLACK);
        Group rootGroup = (Group) scene.getRoot();
        rootGroup.getChildren().add(line);
    }

    private void handleKeyPress(KeyCode code) {
        if (code == KeyCode.K && newLadder) {
            // Increase the line length while the 'K' key is pressed
            line.setStrokeWidth(3);
            lineLength += 0.1;
            updateLine();
        }
    }

    private void handleKeyRelease() {
        // Handle any logic when the key is released (if needed)
        newLadder = false;
        rotataLine();
        newLadder = true;

//        checkLadder();
    }

    private void updateLine() {
        // Update the line with the new length
        line.setEndY(line.getEndY() - lineLength);
        ladderEndCoordinate += lineLength;
    }

    private void rotataLine() {
        Transition rotate = new Transition() {
            {
                setCycleDuration(Duration.millis(500));
            }

            @Override
            protected void interpolate(double frac) {
                double angle = frac * 90.0;
                Rotate rotation = new Rotate(angle, line.getStartX(), line.getStartY());
                line.getTransforms().setAll(rotation);
            }
        };

        rotate.setOnFinished(event -> {
            checkLadder();
        });

        rotate.play();
    }

    private double randomNumberGenerator(double lowerLimit, double upperLimit) {
        Random random = new Random();
        return random.nextDouble(upperLimit - lowerLimit + 1) + lowerLimit;
    }

    private void generateHills() {
        double length = 200;
        breadth = randomNumberGenerator(40.0, 120.0);
        xCoordinate = randomNumberGenerator(prevBase, 480.0);

        System.out.println("breadth and xCoordinate : " + breadth + ", " + xCoordinate + " " + (600-xCoordinate));

        if(breadth + xCoordinate <= 600){
            prevBase = breadth;
            System.out.println("prevBase : " + prevBase);

            rectangle = new Rectangle(breadth, length);
            rectangle.setLayoutY(500);
            rectangle.setLayoutX(600 - breadth);
            rectangle.setFill(Color.BLACK);

            midRectangle = new Rectangle(5,5);
            midRectangle.setLayoutY(500);
            midRectangle.setLayoutX(600 - (breadth / 2));
            midRectangle.setFill(Color.RED);

            Group rootGroup = (Group) scene.getRoot();
            rootGroup.getChildren().add(rectangle);
            rootGroup.getChildren().add(midRectangle);

            List<Double> list = new ArrayList<>();
            list.add(xCoordinate);
            list.add(breadth);
            hillList.add(list);

            // Create a TranslateTransition to move the rectangle to its final position
            TranslateTransition transition = new TranslateTransition();
            transition.setNode(rectangle);
            transition.setByX(xCoordinate + breadth - 600);
            transition.setDuration(Duration.seconds(1));

            TranslateTransition midTransition = new TranslateTransition();
            midTransition.setNode(midRectangle);
            midTransition.setByX(xCoordinate + breadth - 600);
            midTransition.setDuration(Duration.seconds(1));

            transition.play();
            midTransition.play();

        }
    }

    private void moveEntireScene() {
        // Move the circle
        TranslateTransition circleTransition = new TranslateTransition();
        circleTransition.setNode(imageView);
        circleTransition.setByX(-xCoordinate);
        circleTransition.setDuration(Duration.seconds(1));
        circleTransition.play();

        // Move the line
        TranslateTransition lineTransition = new TranslateTransition();
        lineTransition.setNode(line);
        lineTransition.setByX(-xCoordinate);
        lineTransition.setDuration(Duration.seconds(1));
        lineTransition.play();

        // Move the line
        TranslateTransition lineTransition2 = new TranslateTransition();
        lineTransition2.setNode(prevLine);
        lineTransition2.setByX(-xCoordinate);
        lineTransition2.setDuration(Duration.seconds(1));
        lineTransition2.play();

        // Move the baseRectangle
        TranslateTransition baseRectangleTransition = new TranslateTransition();
        baseRectangleTransition.setNode(startRectangle);
        baseRectangleTransition.setByX(-xCoordinate);
        baseRectangleTransition.setDuration(Duration.seconds(1));
        baseRectangleTransition.play();

        // Move the rectangle
        TranslateTransition rectangleTransition = new TranslateTransition();
        rectangleTransition.setNode(rectangle);
        rectangleTransition.setByX(-xCoordinate);
        rectangleTransition.setDuration(Duration.seconds(1));
        rectangleTransition.play();

        // Move the midrectangle
        TranslateTransition midRectangleTransition = new TranslateTransition();
        midRectangleTransition.setNode(midRectangle);
        midRectangleTransition.setByX(-xCoordinate);
        midRectangleTransition.setDuration(Duration.seconds(1));
        midRectangleTransition.play();

        // Move the baseMidRectangle
        TranslateTransition baseMidRectangleTransition = new TranslateTransition();
        baseMidRectangleTransition.setNode(baseMidRectangle);
        baseMidRectangleTransition.setByX(-xCoordinate);
        baseMidRectangleTransition.setDuration(Duration.seconds(1));
        baseMidRectangleTransition.play();

        baseMidRectangle = midRectangle;
        startRectangle = rectangle;

        prevLine = line;

        startx = breadth;
        starty = 500;
        endx = breadth;
        endy = 500;
        ladderEndCoordinate = breadth;

        addLine();
    }

    private void runParallel() {
        Platform.runLater(() -> {
            moveEntireScene();
            generateHills();
        });
    }
    @FXML
    private void exitApplication() {
        Platform.exit();
    }

}